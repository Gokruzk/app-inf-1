﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinAppPrueba7046
{
    public partial class SumForm : Form
    {
        public SumForm()
        {
            InitializeComponent();
        }
    }
}
